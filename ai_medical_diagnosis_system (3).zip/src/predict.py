
import pandas as pd
import joblib

# Load model
model = joblib.load("models/random_forest_model.pkl")

# Example input
symptoms = {"symptom1": "fever", "symptom2": "cough", "symptom3": "headache"}
input_df = pd.DataFrame([symptoms])
input_df = pd.get_dummies(input_df)

# Align input to model features (pad missing columns)
model_features = model.feature_names_in_
for col in model_features:
    if col not in input_df.columns:
        input_df[col] = 0
input_df = input_df[model_features]

# Predict
prediction = model.predict(input_df)
print("Predicted disease:", prediction)
